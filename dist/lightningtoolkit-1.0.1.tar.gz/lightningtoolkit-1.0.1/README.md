# Lightning Toolkit

## English
### Project Description
- 
###### tips: you need anaconda,miniconda or other Python3.10 Interpreter to run in shell.

## 中文

### 项目说明
- 此项目是一个工具包
- github：https://github.com/BinaryGuo/Lightning_Toolkit/
- 问题反馈：https://github.com/BinaryGuo/Lightning_Toolkit/issues
- 联系邮箱（GQX）：kill114514251@outlook.com
- testPyPI：同名

### 开发环境
- Ubuntu Linux 22.04
- Python 3.10.12

### 改动说明
- 此版本是第一个版本

### 问题修复
- 无

### 程序说明
#### 安装方法
在shell上执行
> pip3 install lightningtoolkit

###### 提示：你需要Python3.10解释器才能在shell上运行。
#